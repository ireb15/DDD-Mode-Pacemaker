/*
***************************************************************************
                 G E N E R A T E D       C    C O D E
***************************************************************************
 KIELER - Kiel Integrated Environment for Layout Eclipse RichClient

 http://www.informatik.uni-kiel.de/rtsys/kieler/
 Copyright 2014 by
 + Kiel University
   + Department of Computer Science
     + Real-Time and Embedded Systems Group

 This code is provided under the terms of the Eclipse Public License (EPL).
***************************************************************************
char ASense;
char APace;
char LRI_stop;
char URI_stop;
char VRP_ex;
char AVI_ex;
char PVARP_ex;
char AEI_ex;
char VSense;
char VPace;
char LRI_start;
char LRI_ex;
char URI_start;
char URI_ex;
char VRP_start;
char VRP_stop;
char AVI_start;
char AVI_stop;
char PVARP_start;
char PVARP_stop;
char AEI_start;
char AEI_stop;
char g0;
char g1;
char g2;
char g3;
char PRE_g3;
char g4;
char g5;
char g6;
char PRE_g6;
char g7;
char g8;
char PRE_g8;
char g9;
char g10;
char g11;
char PRE_g11;
char g12;
char g13;
char g14;
char g15;
char g16;
char g17;
char g18;
char g19;
char PRE_g19;
char g20;
char g21;
char g22;
char PRE_g22;
char g23;
char g24;
char g25;
char g26;
char g27;
char g28;
char g29;
char PRE_g29;
char g30;
char g30b;
char g31;
char PRE_g31;
char g32;
char g32b;
char g33;
char g34;
char g35;
char g36;
char PRE_g36;
char g37;
char g37b;
char g38;
char PRE_g38;
char g39;
char g39b;
char g40;
char g41;
char g42;
char g43;
char PRE_g43;
char g44;
char g45;
char g46;
char PRE_g46;
char g47;
char g48;
char g49;
char g50;
char g51;
char g52;
char PRE_g52;
char g53;
char g53b;
char g54;
char PRE_g54;
char g55;
char g56;
char g57;
char g58;
char g59;
char PRE_g59;
char g60;
char g61;
char PRE_g61;
char g62;
char g63;
char g64;
char PRE_g64;
char g65;
char g66;
char g67;
char g68;
char PRE_g68;
char g69;
char g70;
char g71;
char g72;
char g73;
char g74;
char g75;
char PRE_g75;
char g76;
char g76b;
char g77;
char PRE_g77;
char g78;
char g79;
char g80;
char g81;
char g82;
char PRE_g82;
char g83;
char g84;
char g85;
char PRE_g85;
char g86;
char g87;
char PRE_g87;
char g88;
char g89;
char g90;
char g91;
char g92;
char g93;
char g94;
char g95;
char g96;
char PRE_g96;
char g97;
char g97b;
char g98;
char PRE_g98;
char g99;
char g100;
char g101;
char g102;
char g103;
char PRE_g103;
char g104;
char g105;
char PRE_g105;
char g106;
char g107;
char g108;
char PRE_g108;
char g109;
char g110;
char g111;
char g112;
char g113;
char g114;
char PRE_g114;
char g115;
char g115b;
char g116;
char PRE_g116;
char g117;
char g118;
char g119;
char g120;
char g121;
char g122;
char PRE_g122;
char g123;
char g124;
char g125;
char _GO;
char _cg15;
char _cg4;
char _cg7;
char _cg13;
char _cg9;
char _cg25;
char _cg20;
char _cg23;
char _cg32;
char _cg33;
char _cg30;
char _cg39;
char _cg40;
char _cg37;
char _cg47;
char _cg49;
char _cg44;
char _cg48;
char _cg55;
char _cg56;
char _cg53;
char _cg60;
char _cg71;
char _cg62;
char _cg67;
char _cg65;
char _cg69;
char _cg78;
char _cg79;
char _cg76;
char _cg92;
char _cg83;
char _cg86;
char _cg90;
char _cg88;
char _cg99;
char _cg100;
char _cg97;
char _cg109;
char _cg104;
char _cg110;
char _cg106;
char _cg117;
char _cg118;
char _cg115;
char g17_e1;
char g27_e2;
char g34_e3;
char g41_e4;
char g50_e5;
char g57_e6;
char g73_e7;
char g80_e8;
char g94_e9;
char g101_e10;
char g112_e11;
char g119_e12;
char g120_fix0;
char g120_fix1;
char g120_fix2;
char g120_fix3;
char g120_e1_fix_fix;
char g120_e1_fix;
char g120_e1;
char g124_e2;
int _PRE_GO;
void reset(){
   _GO = 1;
   _PRE_GO = 0;
   PRE_g3 = 0;
   PRE_g6 = 0;
   PRE_g8 = 0;
   PRE_g11 = 0;
   PRE_g19 = 0;
   PRE_g22 = 0;
   PRE_g29 = 0;
   PRE_g31 = 0;
   PRE_g36 = 0;
   PRE_g38 = 0;
   PRE_g43 = 0;
   PRE_g46 = 0;
   PRE_g52 = 0;
   PRE_g54 = 0;
   PRE_g59 = 0;
   PRE_g61 = 0;
   PRE_g64 = 0;
   PRE_g68 = 0;
   PRE_g75 = 0;
   PRE_g77 = 0;
   PRE_g82 = 0;
   PRE_g85 = 0;
   PRE_g87 = 0;
   PRE_g96 = 0;
   PRE_g98 = 0;
   PRE_g103 = 0;
   PRE_g105 = 0;
   PRE_g108 = 0;
   PRE_g114 = 0;
   PRE_g116 = 0;
   PRE_g122 = 0;
   return;
}
void tick(){
   if(_PRE_GO == 1){
      _GO = 0;
   }
   {
      g0 = _GO;
      g1 = g0;
      g2 = g1;
      g121 = g0;
      g123 =(PRE_g122);
      g122 =(g121||g123);
      if(g122){
         VPace = 0;
         APace = 0;
      }
      g69 =(PRE_g68);
      _cg69 = URI_ex;
      g70 =(g69&&_cg69);
      if(g70){
         VPace =(VPace||1);
      }
      g4 =(PRE_g3);
      _cg4 = VSense;
      g15 =(g4&&(!(_cg4)));
      _cg15 = VPace;
      g3 =((g15&&(!(_cg15)))||g2);
      g5 =(g4&&_cg4);
      if(g5){
         LRI_start =(LRI_start||1);
      }
      g12 =(PRE_g11);
      if(g12){
         LRI_start =(LRI_start||1);
      }
      g7 =(PRE_g6);
      _cg7 = VRP_ex;
      g16 =(g15&&_cg15);
      if(g16){
         LRI_start =(LRI_start||1);
      }
      g6 =(g5||g12||(g7&&(!(_cg7)))||g16);
      g9 =(PRE_g8);
      _cg9 = VSense;
      g13 =(g9&&(!(_cg9)));
      _cg13 = LRI_ex;
      g8 =((g13&&(!(_cg13)))||(g7&&_cg7));
      g10 =(g9&&_cg9);
      if(g10){
         LRI_stop =(LRI_stop||1);
      }
      g14 =(g13&&_cg13);
      if(g14){
         VPace =(VPace||1);
      }
      g11 =(g10||g14);
      g18 = g1;
      g20 =(PRE_g19);
      _cg20 = VSense;
      g25 =(g20&&(!(_cg20)));
      _cg25 = VPace;
      g23 =(PRE_g22);
      _cg23 = URI_ex;
      g24 =(g23&&_cg23);
      if(g24){
         URI_stop =(URI_stop||1);
      }
      g19 =(g18||(g25&&(!(_cg25)))||g24);
      g21 =(g20&&_cg20);
      if(g21){
         URI_start =(URI_start||1);
      }
      g26 =(g25&&_cg25);
      if(g26){
         URI_start =(URI_start||1);
      }
      g22 =(g21||g26||(g23&&(!(_cg23))));
      g28 = g1;
      g32 =(PRE_g31);
      g32b = g32;
      _cg32 = LRI_stop;
      g30 =(PRE_g29);
      g30b = g30;
      _cg30 = LRI_start;
      g33 =(g32b&&(!(_cg32)));
      _cg33 = LRI_ex;
      g29 =(g28||(g32b&&_cg32)||(g30b&&(!(_cg30)))||(g33&&_cg33));
      g31 =((g30b&&_cg30)||(g33&&(!(_cg33))));
      g35 = g1;
      g39 =(PRE_g38);
      g39b = g39;
      _cg39 = URI_stop;
      g40 =(g39b&&(!(_cg39)));
      _cg40 = URI_ex;
      g37 =(PRE_g36);
      g37b = g37;
      _cg37 = URI_start;
      g36 =((g40&&_cg40)||g35||(g39b&&_cg39)||(g37b&&(!(_cg37))));
      g38 =((g37b&&_cg37)||(g40&&(!(_cg40))));
      g42 = g1;
      g44 =(PRE_g43);
      _cg44 = VSense;
      g49 =(g44&&(!(_cg44)));
      _cg49 = VPace;
      g47 =(PRE_g46);
      _cg47 = VRP_ex;
      g43 =((g49&&(!(_cg49)))||g42||(g47&&_cg47));
      g45 =((g44&&_cg44)||(g49&&_cg49));
      if(g45){
         VRP_start =(VRP_start||1);
      }
      g48 =(g47&&(!(_cg47)));
      _cg48 = VSense;
      g46 =((g48&&_cg48)||(g48&&_cg48)||g45);
      g51 = g1;
      g55 =(PRE_g54);
      _cg55 = VRP_ex;
      g53 =(PRE_g52);
      g53b = g53;
      _cg53 = VRP_start;
      g56 =(g55&&(!(_cg55)));
      _cg56 = VRP_stop;
      g52 =((g55&&_cg55)||(g53b&&(!(_cg53)))||(g56&&_cg56)||g51);
      g54 =((g53b&&_cg53)||(g56&&(!(_cg56))));
      g58 = g1;
      g60 =(PRE_g59);
      _cg60 = PVARP_ex;
      g65 =(PRE_g64);
      _cg65 = VSense;
      g66 =(g65&&_cg65);
      if(g66){
         AVI_stop =(AVI_stop||1);
      }
      g59 =((g60&&(!(_cg60)))||g58||g70||g66);
      g88 =(PRE_g87);
      _cg88 = ASense;
      g90 =(g88&&(!(_cg88)));
      _cg90 = AEI_ex;
      g91 =(g90&&_cg90);
      if(g91){
         APace =(APace||1);
      }
      g62 =(PRE_g61);
      _cg62 = ASense;
      g71 =(g62&&(!(_cg62)));
      _cg71 = APace;
      g61 =((g71&&(!(_cg71)))||(g60&&_cg60));
      g63 =(g62&&_cg62);
      if(g63){
         AVI_start =(AVI_start||1);
      }
      g72 =(g71&&_cg71);
      if(g72){
         AVI_start =(AVI_start||1);
      }
      g67 =(g65&&(!(_cg65)));
      _cg67 = AVI_ex;
      g64 =(g72||g63||(g67&&(!(_cg67))));
      g68 =((g69&&(!(_cg69)))||(g67&&_cg67));
      g74 = g1;
      g78 =(PRE_g77);
      _cg78 = AVI_ex;
      g79 =(g78&&(!(_cg78)));
      _cg79 = AVI_stop;
      g76 =(PRE_g75);
      g76b = g76;
      _cg76 = AVI_start;
      g75 =((g79&&_cg79)||g74||(g76b&&(!(_cg76)))||(g78&&_cg78));
      g77 =((g79&&(!(_cg79)))||(g76b&&_cg76));
      g81 = g1;
      g83 =(PRE_g82);
      _cg83 = VSense;
      g92 =(g83&&(!(_cg83)));
      _cg92 = VPace;
      g89 =(g88&&_cg88);
      if(g89){
         AEI_stop =(AEI_stop||1);
      }
      g82 =(g91||(g92&&(!(_cg92)))||g89||g81);
      g84 =(g83&&_cg83);
      if(g84){
         AEI_start =(AEI_start||1);
      }
      g86 =(PRE_g85);
      _cg86 = PVARP_ex;
      g93 =(g92&&_cg92);
      if(g93){
         AEI_start =(AEI_start||1);
      }
      g85 =(g84||(g86&&(!(_cg86)))||g93);
      g87 =((g86&&_cg86)||(g90&&(!(_cg90))));
      g95 = g1;
      g97 =(PRE_g96);
      g97b = g97;
      _cg97 = AEI_start;
      g99 =(PRE_g98);
      _cg99 = AEI_ex;
      g100 =(g99&&(!(_cg99)));
      _cg100 = AEI_stop;
      g96 =((g97b&&(!(_cg97)))||(g100&&_cg100)||(g99&&_cg99)||g95);
      g98 =((g97b&&_cg97)||(g100&&(!(_cg100))));
      g102 = g1;
      g109 =(PRE_g108);
      _cg109 = PVARP_ex;
      g104 =(PRE_g103);
      _cg104 = VRP_ex;
      g103 =(g102||(g109&&_cg109)||(g104&&(!(_cg104))));
      g106 =(PRE_g105);
      _cg106 = VSense;
      g110 =(g106&&(!(_cg106)));
      _cg110 = VPace;
      g105 =((g110&&(!(_cg110)))||(g104&&_cg104));
      g107 =(g106&&_cg106);
      if(g107){
         PVARP_start =(PVARP_start||1);
      }
      g111 =(g110&&_cg110);
      if(g111){
         PVARP_start =(PVARP_start||1);
      }
      g108 =(g107||(g109&&(!(_cg109)))||g111);
      g113 = g1;
      g115 =(PRE_g114);
      g115b = g115;
      _cg115 = PVARP_start;
      g117 =(PRE_g116);
      _cg117 = PVARP_ex;
      g118 =(g117&&(!(_cg117)));
      _cg118 = PVARP_stop;
      g114 =((g115b&&(!(_cg115)))||(g117&&_cg117)||g113||(g118&&_cg118));
      g116 =((g118&&(!(_cg118)))||(g115b&&_cg115));
      g17_e1 =(!((g4||g7||g9||g12)));
      g27_e2 =(!((g20||g23)));
      g34_e3 =(!((g30||g32)));
      g41_e4 =(!((g37||g39)));
      g50_e5 =(!((g44||g47)));
      g57_e6 =(!((g53||g55)));
      g73_e7 =(!((g60||g62||g65||g69)));
      g80_e8 =(!((g76||g78)));
      g94_e9 =(!((g83||g86||g88)));
      g101_e10 =(!((g97||g99)));
      g112_e11 =(!((g104||g106||g109)));
      g119_e12 =(!((g115||g117)));
      g120_fix0 =((g17_e1||g17)&&(g27_e2||g27)&&(g34_e3||g34)&&(g41_e4||g41));
      g120_fix1 =(g120_fix0&&(g50_e5||g50)&&(g57_e6||g57)&&(g73_e7||g73));
      g120_fix2 =(g17||g27||g34||g41);
      g120_fix3 =(g120_fix2||g50||g57||g73);
      g120_e1_fix_fix =(g78||g99||g106||g117||g7||g23||g47||g86||g9||g65||g88||g109);
      g120_e1_fix =(g83||g97||g104||g115||g32||g39||g55||g62||g12||g120_e1_fix_fix);
      g120_e1 =(!((g4||g20||g30||g37||g44||g53||g60||g76||g69||g120_e1_fix)));
      g124_e2 =(!(g123));
   }
   PRE_g3 = g3;
   PRE_g6 = g6;
   PRE_g8 = g8;
   PRE_g11 = g11;
   PRE_g19 = g19;
   PRE_g22 = g22;
   PRE_g29 = g29;
   PRE_g31 = g31;
   PRE_g36 = g36;
   PRE_g38 = g38;
   PRE_g43 = g43;
   PRE_g46 = g46;
   PRE_g52 = g52;
   PRE_g54 = g54;
   PRE_g59 = g59;
   PRE_g61 = g61;
   PRE_g64 = g64;
   PRE_g68 = g68;
   PRE_g75 = g75;
   PRE_g77 = g77;
   PRE_g82 = g82;
   PRE_g85 = g85;
   PRE_g87 = g87;
   PRE_g96 = g96;
   PRE_g98 = g98;
   PRE_g103 = g103;
   PRE_g105 = g105;
   PRE_g108 = g108;
   PRE_g114 = g114;
   PRE_g116 = g116;
   PRE_g122 = g122;
   _PRE_GO = _GO;
   return;
}
*/

/*****************************************************************************/
/*                 G E N E R A T E D       C    C O D E                      */
/*****************************************************************************/
/* KIELER - Kiel Integrated Environment for Layout Eclipse RichClient        */
/*                                                                           */
/* http://www.informatik.uni-kiel.de/rtsys/kieler/                           */
/* Copyright 2014 by                                                         */
/* + Kiel University                                                         */
/*   + Department of Computer Science                                        */
/*     + Real-Time and Embedded Systems Group                                */
/*                                                                           */
/* This code is provided under the terms of the Eclipse Public License (EPL).*/
/*****************************************************************************/
char ASense;
char APace;
char init_var;
char VSense;
char VPace;
char _Mode1_local_LRI_stop;
char _Mode1_local_URI_stop;
char _Mode1_local_VRP_ex;
char _Mode1_local_AVI_ex;
char _Mode1_local_PVARP_ex;
char _Mode1_local_AEI_ex;
char _Mode1_local_LRI_start;
char _Mode1_local_LRI_ex;
char _Mode1_local_URI_start;
char _Mode1_local_URI_ex;
char _Mode1_local_VRP_start;
char _Mode1_local_VRP_stop;
char _Mode1_local_AVI_start;
char _Mode1_local_AVI_stop;
char _Mode1_local_PVARP_start;
char _Mode1_local_PVARP_stop;
char _Mode1_local_AEI_start;
char _Mode1_local_AEI_stop;
char g0;
char g1;
char g2;
char g3;
char PRE_g3;
char g4;
char g5;
char g5b;
char g5c;
char g5d;
char g5e;
char g6;
char PRE_g6;
char g7;
char g8;
char g9;
char g10;
char PRE_g10;
char g11;
char g12;
char g13;
char PRE_g13;
char g14;
char g14b;
char g15;
char PRE_g15;
char g16;
char g17;
char g18;
char PRE_g18;
char g19;
char g19b;
char g20;
char g21;
char g22;
char g23;
char g24;
char g25;
char g26;
char PRE_g26;
char g27;
char g28;
char g29;
char PRE_g29;
char g30;
char g30b;
char g31;
char g32;
char g33;
char g34;
char g35;
char g36;
char PRE_g36;
char g37;
char g37b;
char g38;
char PRE_g38;
char g39;
char g39b;
char g40;
char g41;
char g42;
char g43;
char PRE_g43;
char g44;
char g44b;
char g45;
char PRE_g45;
char g46;
char g46b;
char g47;
char g48;
char g49;
char g50;
char PRE_g50;
char g51;
char g52;
char g53;
char PRE_g53;
char g54;
char g54b;
char g55;
char g56;
char g57;
char g58;
char g59;
char PRE_g59;
char g60;
char g60b;
char g61;
char PRE_g61;
char g62;
char g62b;
char g63;
char g64;
char g65;
char g66;
char PRE_g66;
char g67;
char g67b;
char g68;
char PRE_g68;
char g69;
char g70;
char g71;
char PRE_g71;
char g72;
char g73;
char g74;
char g75;
char PRE_g75;
char g76;
char g76b;
char g77;
char g78;
char g79;
char g80;
char g81;
char g82;
char PRE_g82;
char g83;
char g83b;
char g84;
char PRE_g84;
char g85;
char g85b;
char g86;
char g87;
char g88;
char g89;
char PRE_g89;
char g90;
char g91;
char g92;
char PRE_g92;
char g93;
char g93b;
char g94;
char PRE_g94;
char g95;
char g96;
char g97;
char g98;
char g99;
char g100;
char g101;
char g102;
char g103;
char PRE_g103;
char g104;
char g104b;
char g105;
char PRE_g105;
char g106;
char g106b;
char g107;
char g108;
char g109;
char g110;
char PRE_g110;
char g111;
char g111b;
char g112;
char PRE_g112;
char g113;
char g114;
char g115;
char PRE_g115;
char g116;
char g116b;
char g117;
char g118;
char g119;
char g120;
char g121;
char PRE_g121;
char g122;
char g122b;
char g123;
char PRE_g123;
char g124;
char g124b;
char g125;
char g126;
char g127;
char g128;
char PRE_g128;
char g129;
char g130;
char g131;
char g132;
char g133;
char PRE_g133;
char g134;
char g135;
char g136;
char _GO;
char _cg4;
char _cg22;
char _cg11;
char _cg14;
char _cg20;
char _cg16;
char _cg32;
char _cg27;
char _cg30;
char _cg39;
char _cg40;
char _cg37;
char _cg46;
char _cg47;
char _cg44;
char _cg54;
char _cg56;
char _cg51;
char _cg55;
char _cg62;
char _cg63;
char _cg60;
char _cg67;
char _cg78;
char _cg69;
char _cg74;
char _cg72;
char _cg76;
char _cg85;
char _cg86;
char _cg83;
char _cg99;
char _cg90;
char _cg93;
char _cg97;
char _cg95;
char _cg106;
char _cg107;
char _cg104;
char _cg116;
char _cg111;
char _cg117;
char _cg113;
char _cg124;
char _cg125;
char _cg122;
char g8_e1;
char g24_e2;
char g34_e3;
char g41_e4;
char g48_e5;
char g57_e6;
char g64_e7;
char g80_e8;
char g87_e9;
char g101_e10;
char g108_e11;
char g119_e12;
char g126_e13;
char g130_e14;
char g131_fix0;
char g131_fix1;
char g131_fix2;
char g131_fix3;
char g131_fix4;
char g131_e1_fix_fix;
char g131_e1_fix;
char g131_e1;
char g135_e2;
int _PRE_GO;
void reset(){
   _GO = 1;
   _PRE_GO = 0;
   PRE_g3 = 0;
   PRE_g6 = 0;
   PRE_g10 = 0;
   PRE_g13 = 0;
   PRE_g15 = 0;
   PRE_g18 = 0;
   PRE_g26 = 0;
   PRE_g29 = 0;
   PRE_g36 = 0;
   PRE_g38 = 0;
   PRE_g43 = 0;
   PRE_g45 = 0;
   PRE_g50 = 0;
   PRE_g53 = 0;
   PRE_g59 = 0;
   PRE_g61 = 0;
   PRE_g66 = 0;
   PRE_g68 = 0;
   PRE_g71 = 0;
   PRE_g75 = 0;
   PRE_g82 = 0;
   PRE_g84 = 0;
   PRE_g89 = 0;
   PRE_g92 = 0;
   PRE_g94 = 0;
   PRE_g103 = 0;
   PRE_g105 = 0;
   PRE_g110 = 0;
   PRE_g112 = 0;
   PRE_g115 = 0;
   PRE_g121 = 0;
   PRE_g123 = 0;
   PRE_g128 = 0;
   PRE_g133 = 0;
   return;
}
void tick(){
   if(_PRE_GO == 1){
      _GO = 0;
   }
   {
      g0 = _GO;
      g1 = g0;
      g2 = g1;
      g4 =(PRE_g3);
      _cg4 = init_var;
      g3 =(g2||(g4&&(!(_cg4))));
      g127 = g1;
      g129 =(PRE_g128);
      g128 =(g127||g129);
      if(g128){
         _Mode1_local_LRI_start = 0;
         _Mode1_local_LRI_ex = 0;
         _Mode1_local_LRI_stop = 0;
         _Mode1_local_URI_start = 0;
         _Mode1_local_URI_ex = 0;
         _Mode1_local_URI_stop = 0;
         _Mode1_local_VRP_start = 0;
         _Mode1_local_VRP_stop = 0;
         _Mode1_local_VRP_ex = 0;
         _Mode1_local_AVI_start = 0;
         _Mode1_local_AVI_stop = 0;
         _Mode1_local_AVI_ex = 0;
         _Mode1_local_PVARP_start = 0;
         _Mode1_local_PVARP_stop = 0;
         _Mode1_local_PVARP_ex = 0;
         _Mode1_local_AEI_start = 0;
         _Mode1_local_AEI_stop = 0;
         _Mode1_local_AEI_ex = 0;
      }
      g5 =(g4&&_cg4);
      if(g5){
         _Mode1_local_PVARP_start =(_Mode1_local_PVARP_start||1);
      }
      g5b = g5;
      if(g5b){
         _Mode1_local_VRP_start =(_Mode1_local_VRP_start||1);
      }
      g5c = g5;
      if(g5c){
         _Mode1_local_AEI_start =(_Mode1_local_AEI_start||1);
      }
      g5d = g5;
      if(g5d){
         _Mode1_local_LRI_start =(_Mode1_local_LRI_start||1);
      }
      g5e = g5;
      if(g5e){
         _Mode1_local_URI_start =(_Mode1_local_URI_start||1);
      }
      g7 =(PRE_g6);
      g6 =(g5e||g7);
      g9 = g1;
      g132 = g0;
      g134 =(PRE_g133);
      g133 =(g132||g134);
      if(g133){
         VPace = 0;
         APace = 0;
      }
      g76 =(PRE_g75);
      g76b = g76;
      _cg76 = _Mode1_local_URI_ex;
      g77 =(g76b&&_cg76);
      if(g77){
         VPace =(VPace||1);
      }
      g11 =(PRE_g10);
      _cg11 = VSense;
      g22 =(g11&&(!(_cg11)));
      _cg22 = VPace;
      g10 =(g9||(g22&&(!(_cg22))));
      g12 =(g11&&_cg11);
      if(g12){
         _Mode1_local_LRI_start =(_Mode1_local_LRI_start||1);
      }
      g19 =(PRE_g18);
      g19b = g19;
      if(g19b){
         _Mode1_local_LRI_start =(_Mode1_local_LRI_start||1);
      }
      g23 =(g22&&_cg22);
      if(g23){
         _Mode1_local_LRI_start =(_Mode1_local_LRI_start||1);
      }
      g14 =(PRE_g13);
      g14b = g14;
      _cg14 = _Mode1_local_VRP_ex;
      g13 =(g19b||g12||g23||(g14b&&(!(_cg14))));
      g16 =(PRE_g15);
      _cg16 = VSense;
      g20 =(g16&&(!(_cg16)));
      _cg20 = _Mode1_local_LRI_ex;
      g15 =((g14b&&_cg14)||(g20&&(!(_cg20))));
      g17 =(g16&&_cg16);
      if(g17){
         _Mode1_local_LRI_stop =(_Mode1_local_LRI_stop||1);
      }
      g21 =(g20&&_cg20);
      if(g21){
         VPace =(VPace||1);
      }
      g18 =(g21||g17);
      g25 = g1;
      g30 =(PRE_g29);
      g30b = g30;
      _cg30 = _Mode1_local_URI_ex;
      g31 =(g30b&&_cg30);
      if(g31){
         _Mode1_local_URI_stop =(_Mode1_local_URI_stop||1);
      }
      g27 =(PRE_g26);
      _cg27 = VSense;
      g32 =(g27&&(!(_cg27)));
      _cg32 = VPace;
      g26 =(g25||g31||(g32&&(!(_cg32))));
      g28 =(g27&&_cg27);
      if(g28){
         _Mode1_local_URI_start =(_Mode1_local_URI_start||1);
      }
      g33 =(g32&&_cg32);
      if(g33){
         _Mode1_local_URI_start =(_Mode1_local_URI_start||1);
      }
      g29 =(g33||g28||(g30b&&(!(_cg30))));
      g35 = g1;
      g39 =(PRE_g38);
      g39b = g39;
      _cg39 = _Mode1_local_LRI_stop;
      g40 =(g39b&&(!(_cg39)));
      _cg40 = _Mode1_local_LRI_ex;
      g37 =(PRE_g36);
      g37b = g37;
      _cg37 = _Mode1_local_LRI_start;
      g36 =((g40&&_cg40)||g35||(g37b&&(!(_cg37)))||(g39b&&_cg39));
      g38 =((g37b&&_cg37)||(g40&&(!(_cg40))));
      g42 = g1;
      g46 =(PRE_g45);
      g46b = g46;
      _cg46 = _Mode1_local_URI_stop;
      g47 =(g46b&&(!(_cg46)));
      _cg47 = _Mode1_local_URI_ex;
      g44 =(PRE_g43);
      g44b = g44;
      _cg44 = _Mode1_local_URI_start;
      g43 =(g42||(g46b&&_cg46)||(g47&&_cg47)||(g44b&&(!(_cg44))));
      g45 =((g44b&&_cg44)||(g47&&(!(_cg47))));
      g49 = g1;
      g54 =(PRE_g53);
      g54b = g54;
      _cg54 = _Mode1_local_VRP_ex;
      g51 =(PRE_g50);
      _cg51 = VSense;
      g56 =(g51&&(!(_cg51)));
      _cg56 = VPace;
      g50 =(g49||(g54b&&_cg54)||(g56&&(!(_cg56))));
      g52 =((g51&&_cg51)||(g56&&_cg56));
      if(g52){
         _Mode1_local_VRP_start =(_Mode1_local_VRP_start||1);
      }
      g55 =(g54b&&(!(_cg54)));
      _cg55 = VSense;
      g53 =(g52||(g55&&_cg55)||(g55&&_cg55));
      g58 = g1;
      g62 =(PRE_g61);
      g62b = g62;
      _cg62 = _Mode1_local_VRP_ex;
      g63 =(g62b&&(!(_cg62)));
      _cg63 = _Mode1_local_VRP_stop;
      g60 =(PRE_g59);
      g60b = g60;
      _cg60 = _Mode1_local_VRP_start;
      g59 =(g58||(g63&&_cg63)||(g62b&&_cg62)||(g60b&&(!(_cg60))));
      g61 =((g63&&(!(_cg63)))||(g60b&&_cg60));
      g65 = g1;
      g72 =(PRE_g71);
      _cg72 = VSense;
      g73 =(g72&&_cg72);
      if(g73){
         _Mode1_local_AVI_stop =(_Mode1_local_AVI_stop||1);
      }
      g67 =(PRE_g66);
      g67b = g67;
      _cg67 = _Mode1_local_PVARP_ex;
      g66 =(g73||g77||(g67b&&(!(_cg67)))||g65);
      g95 =(PRE_g94);
      _cg95 = ASense;
      g97 =(g95&&(!(_cg95)));
      _cg97 = _Mode1_local_AEI_ex;
      g98 =(g97&&_cg97);
      if(g98){
         APace =(APace||1);
      }
      g69 =(PRE_g68);
      _cg69 = ASense;
      g78 =(g69&&(!(_cg69)));
      _cg78 = APace;
      g68 =((g78&&(!(_cg78)))||(g67b&&_cg67));
      g70 =(g69&&_cg69);
      if(g70){
         _Mode1_local_AVI_start =(_Mode1_local_AVI_start||1);
      }
      g74 =(g72&&(!(_cg72)));
      _cg74 = _Mode1_local_AVI_ex;
      g79 =(g78&&_cg78);
      if(g79){
         _Mode1_local_AVI_start =(_Mode1_local_AVI_start||1);
      }
      g71 =((g74&&(!(_cg74)))||g70||g79);
      g75 =((g74&&_cg74)||(g76b&&(!(_cg76))));
      g81 = g1;
      g85 =(PRE_g84);
      g85b = g85;
      _cg85 = _Mode1_local_AVI_ex;
      g86 =(g85b&&(!(_cg85)));
      _cg86 = _Mode1_local_AVI_stop;
      g83 =(PRE_g82);
      g83b = g83;
      _cg83 = _Mode1_local_AVI_start;
      g82 =((g85b&&_cg85)||(g86&&_cg86)||g81||(g83b&&(!(_cg83))));
      g84 =((g83b&&_cg83)||(g86&&(!(_cg86))));
      g88 = g1;
      g90 =(PRE_g89);
      _cg90 = VSense;
      g99 =(g90&&(!(_cg90)));
      _cg99 = VPace;
      g96 =(g95&&_cg95);
      if(g96){
         _Mode1_local_AEI_stop =(_Mode1_local_AEI_stop||1);
      }
      g89 =(g88||g98||(g99&&(!(_cg99)))||g96);
      g91 =(g90&&_cg90);
      if(g91){
         _Mode1_local_AEI_start =(_Mode1_local_AEI_start||1);
      }
      g100 =(g99&&_cg99);
      if(g100){
         _Mode1_local_AEI_start =(_Mode1_local_AEI_start||1);
      }
      g93 =(PRE_g92);
      g93b = g93;
      _cg93 = _Mode1_local_PVARP_ex;
      g92 =(g91||g100||(g93b&&(!(_cg93))));
      g94 =((g93b&&_cg93)||(g97&&(!(_cg97))));
      g102 = g1;
      g106 =(PRE_g105);
      g106b = g106;
      _cg106 = _Mode1_local_AEI_ex;
      g104 =(PRE_g103);
      g104b = g104;
      _cg104 = _Mode1_local_AEI_start;
      g107 =(g106b&&(!(_cg106)));
      _cg107 = _Mode1_local_AEI_stop;
      g103 =((g106b&&_cg106)||(g104b&&(!(_cg104)))||g102||(g107&&_cg107));
      g105 =((g107&&(!(_cg107)))||(g104b&&_cg104));
      g109 = g1;
      g116 =(PRE_g115);
      g116b = g116;
      _cg116 = _Mode1_local_PVARP_ex;
      g111 =(PRE_g110);
      g111b = g111;
      _cg111 = _Mode1_local_VRP_ex;
      g110 =((g116b&&_cg116)||(g111b&&(!(_cg111)))||g109);
      g113 =(PRE_g112);
      _cg113 = VSense;
      g117 =(g113&&(!(_cg113)));
      _cg117 = VPace;
      g112 =((g111b&&_cg111)||(g117&&(!(_cg117))));
      g114 =(g113&&_cg113);
      if(g114){
         _Mode1_local_PVARP_start =(_Mode1_local_PVARP_start||1);
      }
      g118 =(g117&&_cg117);
      if(g118){
         _Mode1_local_PVARP_start =(_Mode1_local_PVARP_start||1);
      }
      g115 =(g118||(g116b&&(!(_cg116)))||g114);
      g120 = g1;
      g122 =(PRE_g121);
      g122b = g122;
      _cg122 = _Mode1_local_PVARP_start;
      g124 =(PRE_g123);
      g124b = g124;
      _cg124 = _Mode1_local_PVARP_ex;
      g125 =(g124b&&(!(_cg124)));
      _cg125 = _Mode1_local_PVARP_stop;
      g121 =(g120||(g122b&&(!(_cg122)))||(g125&&_cg125)||(g124b&&_cg124));
      g123 =((g122b&&_cg122)||(g125&&(!(_cg125))));
      g8_e1 =(!((g4||g7)));
      g24_e2 =(!((g11||g14||g16||g19)));
      g34_e3 =(!((g27||g30)));
      g41_e4 =(!((g37||g39)));
      g48_e5 =(!((g44||g46)));
      g57_e6 =(!((g51||g54)));
      g64_e7 =(!((g60||g62)));
      g80_e8 =(!((g67||g69||g72||g76)));
      g87_e9 =(!((g83||g85)));
      g101_e10 =(!((g90||g93||g95)));
      g108_e11 =(!((g104||g106)));
      g119_e12 =(!((g111||g113||g116)));
      g126_e13 =(!((g122||g124)));
      g130_e14 =(!(g129));
      g131_fix0 =((g8_e1||g8)&&(g24_e2||g24)&&(g34_e3||g34)&&(g41_e4||g41));
      g131_fix1 =(g131_fix0&&(g48_e5||g48)&&(g57_e6||g57)&&(g64_e7||g64));
      g131_fix2 =(g131_fix1&&(g80_e8||g80)&&(g87_e9||g87)&&(g101_e10||g101));
      g131_fix3 =(g8||g24||g34||g41);
      g131_fix4 =(g131_fix3||g48||g57||g64);
      g131_e1_fix_fix =(g69||g85||g106||g113||g124||g14||g30||g54||g93||g16||g72||g95||g116||g7||g19);
      g131_e1_fix =(g83||g90||g104||g111||g122||g39||g46||g62||g76||g131_e1_fix_fix);
      g131_e1 =(!((g4||g11||g27||g37||g44||g51||g60||g67||g129||g131_e1_fix)));
      g135_e2 =(!(g134));
   }
   PRE_g3 = g3;
   PRE_g6 = g6;
   PRE_g10 = g10;
   PRE_g13 = g13;
   PRE_g15 = g15;
   PRE_g18 = g18;
   PRE_g26 = g26;
   PRE_g29 = g29;
   PRE_g36 = g36;
   PRE_g38 = g38;
   PRE_g43 = g43;
   PRE_g45 = g45;
   PRE_g50 = g50;
   PRE_g53 = g53;
   PRE_g59 = g59;
   PRE_g61 = g61;
   PRE_g66 = g66;
   PRE_g68 = g68;
   PRE_g71 = g71;
   PRE_g75 = g75;
   PRE_g82 = g82;
   PRE_g84 = g84;
   PRE_g89 = g89;
   PRE_g92 = g92;
   PRE_g94 = g94;
   PRE_g103 = g103;
   PRE_g105 = g105;
   PRE_g110 = g110;
   PRE_g112 = g112;
   PRE_g115 = g115;
   PRE_g121 = g121;
   PRE_g123 = g123;
   PRE_g128 = g128;
   PRE_g133 = g133;
   _PRE_GO = _GO;
   return;
}

